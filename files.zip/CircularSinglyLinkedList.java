public class CircularSinglyLinkedList {

    static class Node {
        int data;
        Node next;
        Node(int data) { this.data = data; }
    }

    private Node head;
    private Node tail;

    public void insertEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
            return;
        }
        tail.next = newNode;
        tail = newNode;
        tail.next = head;
    }

    public boolean delete(int data) {
        if (head == null) return false;

        if (head == tail && head.data == data) {
            head = null;
            tail = null;
            return true;
        }

        if (head.data == data) {
            head = head.next;
            tail.next = head;
            return true;
        }

        Node prev = head;
        Node curr = head.next;
        while (curr != head) {
            if (curr.data == data) {
                prev.next = curr.next;
                if (curr == tail) tail = prev;
                return true;
            }
            prev = curr;
            curr = curr.next;
        }
        return false;
    }

    public boolean search(int data) {
        if (head == null) return false;
        Node temp = head;
        do {
            if (temp.data == data) return true;
            temp = temp.next;
        } while (temp != head);
        return false;
    }

    public void traverse() {
        if (head == null) {
            System.out.println("Empty list");
            return;
        }
        Node temp = head;
        StringBuilder sb = new StringBuilder();
        do {
            sb.append(temp.data).append(" -> ");
            temp = temp.next;
        } while (temp != head);
        sb.append("(back to head)");
        System.out.println(sb.toString());
    }

    public static void main(String[] args) {
        CircularSinglyLinkedList list = new CircularSinglyLinkedList();
        list.insertEnd(1);
        list.insertEnd(2);
        list.insertEnd(3);

        System.out.print("List: ");
        list.traverse();

        System.out.println("Search 2: " + list.search(2));

        list.delete(2);
        System.out.print("After deleting 2: ");
        list.traverse();
    }
}
