public class DoublyLinkedList {

    static class Node {
        int data;
        Node prev;
        Node next;
        Node(int data) { this.data = data; }
    }

    private Node head;
    private Node tail;

    public void insertEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
            return;
        }
        tail.next = newNode;
        newNode.prev = tail;
        tail = newNode;
    }

    public void insertBeginning(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
            return;
        }
        newNode.next = head;
        head.prev = newNode;
        head = newNode;
    }

    public boolean delete(int data) {
        Node temp = head;
        while (temp != null && temp.data != data) temp = temp.next;
        if (temp == null) return false;

        if (temp.prev != null) temp.prev.next = temp.next;
        else head = temp.next;

        if (temp.next != null) temp.next.prev = temp.prev;
        else tail = temp.prev;

        return true;
    }

    public boolean search(int data) {
        Node temp = head;
        while (temp != null) {
            if (temp.data == data) return true;
            temp = temp.next;
        }
        return false;
    }

    public void traverseForward() {
        Node temp = head;
        StringBuilder sb = new StringBuilder();
        while (temp != null) {
            sb.append(temp.data);
            if (temp.next != null) sb.append(" <-> ");
            temp = temp.next;
        }
        System.out.println(sb.length() == 0 ? "Empty list" : sb.toString());
    }

    public void traverseBackward() {
        Node temp = tail;
        StringBuilder sb = new StringBuilder();
        while (temp != null) {
            sb.append(temp.data);
            if (temp.prev != null) sb.append(" <-> ");
            temp = temp.prev;
        }
        System.out.println(sb.length() == 0 ? "Empty list" : sb.toString());
    }

    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.insertEnd(10);
        list.insertEnd(20);
        list.insertEnd(30);
        list.insertBeginning(5);

        System.out.print("Forward: ");
        list.traverseForward();

        System.out.print("Backward: ");
        list.traverseBackward();

        list.delete(20);
        System.out.print("After deleting 20 (forward): ");
        list.traverseForward();
    }
}
