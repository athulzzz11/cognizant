public class ArrayOperations {

    static void traverse(int[] arr, int size) {
        for (int i = 0; i < size; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }

    static int insert(int[] arr, int size, int index, int value) {
        if (size >= arr.length || index < 0 || index > size) {
            throw new IllegalArgumentException("Invalid insert operation");
        }
        for (int i = size; i > index; i--) {
            arr[i] = arr[i - 1];
        }
        arr[index] = value;
        return size + 1;
    }

    static int delete(int[] arr, int size, int index) {
        if (index < 0 || index >= size) {
            throw new IllegalArgumentException("Invalid delete operation");
        }
        for (int i = index; i < size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        return size - 1;
    }

    static int search(int[] arr, int size, int key) {
        for (int i = 0; i < size; i++) {
            if (arr[i] == key) return i;
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = new int[10];
        arr[0] = 10; arr[1] = 20; arr[2] = 30; arr[3] = 40;
        int size = 4;

        System.out.print("Initial array: ");
        traverse(arr, size);

        size = insert(arr, size, 2, 25);
        System.out.print("After inserting 25 at index 2: ");
        traverse(arr, size);

        size = delete(arr, size, 0);
        System.out.print("After deleting element at index 0: ");
        traverse(arr, size);

        int index = search(arr, size, 30);
        System.out.println("Index of value 30: " + index);
    }
}
