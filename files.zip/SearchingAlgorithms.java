import java.util.Arrays;

public class SearchingAlgorithms {

    static int linearSearch(int[] arr, int key) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) return i;
        }
        return -1;
    }

    static int binarySearchIterative(int[] sortedArr, int key) {
        int low = 0, high = sortedArr.length - 1;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            if (sortedArr[mid] == key) return mid;
            else if (sortedArr[mid] < key) low = mid + 1;
            else high = mid - 1;
        }
        return -1;
    }

    static int binarySearchRecursive(int[] sortedArr, int key, int low, int high) {
        if (low > high) return -1;
        int mid = low + (high - low) / 2;
        if (sortedArr[mid] == key) return mid;
        else if (sortedArr[mid] < key) return binarySearchRecursive(sortedArr, key, mid + 1, high);
        else return binarySearchRecursive(sortedArr, key, low, mid - 1);
    }

    public static void main(String[] args) {
        int[] arr = {5, 2, 9, 1, 7, 3};
        System.out.println("Array: " + Arrays.toString(arr));
        System.out.println("Linear search for 7: index " + linearSearch(arr, 7));

        int[] sorted = arr.clone();
        Arrays.sort(sorted);
        System.out.println("Sorted array: " + Arrays.toString(sorted));
        System.out.println("Binary search (iterative) for 7: index " + binarySearchIterative(sorted, 7));
        System.out.println("Binary search (recursive) for 7: index "
                + binarySearchRecursive(sorted, 7, 0, sorted.length - 1));
        System.out.println("Binary search for 100 (not present): index "
                + binarySearchIterative(sorted, 100));
    }
}
