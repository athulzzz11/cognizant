public class CircularDoublyLinkedList {

    static class Node {
        int data;
        Node prev;
        Node next;
        Node(int data) { this.data = data; }
    }

    private Node head;
    private Node tail;

    public void insertEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
            head.next = head;
            head.prev = head;
            return;
        }
        newNode.prev = tail;
        newNode.next = head;
        tail.next = newNode;
        head.prev = newNode;
        tail = newNode;
    }

    public boolean delete(int data) {
        if (head == null) return false;

        if (head == tail && head.data == data) {
            head = null;
            tail = null;
            return true;
        }

        Node temp = head;
        do {
            if (temp.data == data) {
                temp.prev.next = temp.next;
                temp.next.prev = temp.prev;
                if (temp == head) head = temp.next;
                if (temp == tail) tail = temp.prev;
                return true;
            }
            temp = temp.next;
        } while (temp != head);

        return false;
    }

    public boolean search(int data) {
        if (head == null) return false;
        Node temp = head;
        do {
            if (temp.data == data) return true;
            temp = temp.next;
        } while (temp != head);
        return false;
    }

    public void traverseForward() {
        if (head == null) {
            System.out.println("Empty list");
            return;
        }
        Node temp = head;
        StringBuilder sb = new StringBuilder();
        do {
            sb.append(temp.data).append(" <-> ");
            temp = temp.next;
        } while (temp != head);
        sb.append("(back to head)");
        System.out.println(sb.toString());
    }

    public static void main(String[] args) {
        CircularDoublyLinkedList list = new CircularDoublyLinkedList();
        list.insertEnd(1);
        list.insertEnd(2);
        list.insertEnd(3);

        System.out.print("List: ");
        list.traverseForward();

        System.out.println("Search 2: " + list.search(2));

        list.delete(2);
        System.out.print("After deleting 2: ");
        list.traverseForward();
    }
}
